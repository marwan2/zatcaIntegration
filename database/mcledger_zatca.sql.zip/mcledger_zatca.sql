-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 12, 2022 at 04:08 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.2.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcledger_zatca`
--

-- --------------------------------------------------------

--
-- Table structure for table `businesses`
--

CREATE TABLE `businesses` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `legal_registration_name` varchar(100) NOT NULL,
  `country_code` varchar(10) NOT NULL,
  `street_name` varchar(100) NOT NULL,
  `building_no` varchar(4) NOT NULL COMMENT 'Must be 4 digits',
  `city` varchar(60) NOT NULL,
  `district` varchar(60) NOT NULL,
  `postal_code` varchar(12) NOT NULL,
  `additional_no` varchar(4) NOT NULL COMMENT 'Plot Indentification',
  `trn` varchar(40) NOT NULL COMMENT 'Must start, end with 3',
  `identification_id` varchar(30) NOT NULL,
  `identification_scheme` enum('CRN','MOM','MLS','SAG','OTH') NOT NULL,
  `auth_token` text NOT NULL,
  `xprefix` varchar(10) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `businesses`
--

INSERT INTO `businesses` (`id`, `name`, `legal_registration_name`, `country_code`, `street_name`, `building_no`, `city`, `district`, `postal_code`, `additional_no`, `trn`, `identification_id`, `identification_scheme`, `auth_token`, `xprefix`, `created_at`, `updated_at`) VALUES
(1, '296_AlphaGreen', 'NEWSA Company Inc.', 'SA', 'ABC street', '5426', 'New City', 'Riyad', '12345', '9874', '315454001007943', '123457890', 'OTH', 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImU2OGIxM2ZhN2M4MWUxM2QzNjIzOWU1Mzk1NTkwMThiMTVhOGViNzRlYzMzNDUwZGI5N2Q5NTBkZmM2ZWNmYmU4ZDQzMzJiNDY0ZTVjZmYxIn0.eyJhdWQiOiI5MzYiLCJqdGkiOiJlNjhiMTNmYTdjODFlMTNkMzYyMzllNTM5NTU5MDE4YjE1YThlYjc0ZWMzMzQ1MGRiOTdkOTUwZGZjNmVjZmJlOGQ0MzMyYjQ2NGU1Y2ZmMSIsImlhdCI6MTY2NDQ1NzQ2MiwibmJmIjoxNjY0NDU3NDYyLCJleHAiOjE2OTU5OTM0NjIsInN1YiI6IjEiLCJzY29wZXMiOltdfQ.fCY9Q8xfzq6bjdjyeONrqa2501oHOHNIZPrXyXCD0I0cMy9552WfTf_BZmIu0f9pZutuOQMr_yBMosM_Kf6Fb9kbvtI3ZPAqvZI2r-meZd79o_6_QllGFFUT7Cb_hd3iLJR0WXPIKZseJU1LR_Ao_EeUAj7k9snqr9Ej6kThFXsHUWjt_7G7Q9F-A1Df3E09Otr8iigH0D3a3CE7QmATtgQLCEc_gy5xCmcVKUA8KKL0xEKU--0wluu9WhTvlfKDRu-iNO3uqF9eBHRbMm3vBYVD-7w4SWu26CPtyEJDyatDDTYDoToDxfsE_y2Y95ZDZUi-4VOyugzSZJsUKyXUY_3D-J7i6N0NP8HoWKbtG954IHjxEW9XvMAUyVKvmQ5Z6Y8OOEM-VuDnP8VOKOxNsnxlM12O77BlPKhyN4o8LW4hqOyocB5YtTtH35vDXIEotofeWb2-JeX47RYREFq2Vpecb4DZWX4JOWxwyy4E5gPGnGFdryqHnB-okl4Fq6z91kji9fgh12dqbW0krUK5Ou-2rM77Zp16aezI7r5w9G6XML_-W9mHQ5qQZw7bmLUS8eWX6YX4jDSGhUmmfSkn-LdjNxnwe6ElIpGIgpciOvf-yxYYfx3UHj04XoSnajdn-eYXqclQ6bTGYMM3P0-URA_btnVeuFqF38LZ9-LkTEY', '296', '2022-09-29 00:00:00', '2022-09-29 00:00:00'),
(2, '579_Reconciliation', '', '', '', '', '', '', '', '', '315459741007943', '', 'CRN', 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImZlZGRiY2Y5ZDJlMzkxOTI2Mjg2ZmRhMWQ1ZmQ4YmRlMDU1NTljM2YzOWYxMzcxMjIyZGQ4OTcyMjU4ZTcyNTI4ZGMwYzg5ZjE4MzEyZWU4In0.eyJhdWQiOiI5MzYiLCJqdGkiOiJmZWRkYmNmOWQyZTM5MTkyNjI4NmZkYTFkNWZkOGJkZTA1NTU5YzNmMzlmMTM3MTIyMmRkODk3MjI1OGU3MjUyOGRjMGM4OWYxODMxMmVlOCIsImlhdCI6MTY2NDE4MDAzNywibmJmIjoxNjY0MTgwMDM3LCJleHAiOjE2OTU3MTYwMzcsInN1YiI6IjkwNiIsInNjb3BlcyI6W119.Y0eCbHbUWVIBOW7J34pWQquBhkgDbpZ8qFqBkHSPg2MfMyE2vOif_PWvGdBmCHWWlaOI_jiZBeB1slKobXUURO8BUTsWXpSK3Tq1ShZUq79ZvvHI…4VUpprcCghZb--oLHrbvR-g8wmdqGVA3NNK7-9wPcG_3-Iecl1Ux__vkQ5-JANVUED0YIl_Y5ATjdC_XkzI1vdC4ilFmRkdxUq67K11v3d38BRP4_yaNOIH37M4-FGJn5aHLb9psGcdXXLQSnuKnYAorpyOs38UL9XJBcyIGDT1WXC5F3eDDV1ySnPFKGMT9hMW1fNyTPZFCO_nCVsHhIh_9NfDsbhZz2nbCu83Czr0boQ22xwdqkKFoUIO_gQUl_zlH1cZD9ctmN4ynuLFElynwaaI_5M9XQunpcXqrBsVHHB0W4OHRZUD47_OsmiD1NbSLEhHcS4lpZP3roy0yAW9Wo88WhreOHRiVhmNGDo8ay1Wl9IkFmRR3OiJ5sujc5liSf2jmiEoOrqUrCw0VfN7NHvYmdA8FXUIsFDMBbNNKMIS-WVoAiIN36cekordXzAmJrag-tQefKQZhDwCLIFEMzYd3ZkL-_xdzRyGRmQB9h1lbDrjeNuSeVDRGZgk', '579', '2022-09-29 00:00:00', '2022-09-29 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `businesses`
--
ALTER TABLE `businesses`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `businesses`
--
ALTER TABLE `businesses`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
